
// ParkYooJinR1View.h : CParkYooJinR1View Ŭ������ �������̽�
//

#include<vector>
#include<string>
#include<string.h>
#include<fstream>
#include<iostream>
using namespace std;
#pragma once


class CParkYooJinR1View : public CView
{
protected: // serialization������ ��������ϴ�.
	CParkYooJinR1View();
	DECLARE_DYNCREATE(CParkYooJinR1View)

// Ư���Դϴ�.
public:
	int pattern;
	int sky;
	int weathers;
	int light;
	CParkYooJinR1Doc* GetDocument() const;
	vector<CString> vt;
	unsigned long long index;
	wofstream file;
	
// �۾��Դϴ�.
public:

// �������Դϴ�.
public:
	virtual void OnDraw(CDC* pDC);  // �� �並 �׸��� ���� �����ǵǾ����ϴ�.
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);

// �����Դϴ�.
public:
	virtual ~CParkYooJinR1View();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// ������ �޽��� �� �Լ�
protected:
	afx_msg void OnFilePrintPreview();
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	DECLARE_MESSAGE_MAP()
public:

	int star;
	void house(CDC* pDC);
	CDC MemDC;
	BITMAP bmpInfo;
	CBitmap bmp;
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	void stair(CDC * pDC);
	void brownWall(CDC* pDC);
	
	void building(CDC* pDC);
	void windows(CDC* pDC,COLORREF color);
	void outLines(CDC* pDC);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	void DrawPattern(CDC* pDC, CPoint point);
	void DrawPattern2(CDC* pDC, CPoint point);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnLightoff();
	afx_msg void OnLighton();
	afx_msg void OnOriginallight();
	afx_msg void OnDaysky();
	afx_msg void OnNightsky();
	afx_msg void OnUpdateDaysky(CCmdUI *pCmdUI);
	afx_msg void OnSnow();
	afx_msg void OnRain();
	afx_msg void OnSunny();
	void backGround(CDC* pDC);
//	afx_msg UINT OnMenuGetObject(MENUGETOBJECTINFO* pMenuGetObjectInfo);
	afx_msg void OnGetMinMaxInfo(MINMAXINFO* lpMMI);
	virtual void OnInitialUpdate();
	afx_msg void OnDestroy();
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
};

#ifndef _DEBUG  // ParkYooJinR1View.cpp�� ����� ����
inline CParkYooJinR1Doc* CParkYooJinR1View::GetDocument() const
   { return reinterpret_cast<CParkYooJinR1Doc*>(m_pDocument); }
#endif

