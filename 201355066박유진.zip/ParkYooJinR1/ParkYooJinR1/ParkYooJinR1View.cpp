
// ParkYooJinR1View.cpp : CParkYooJinR1View Ŭ������ ����
//

#include "stdafx.h"
// SHARED_HANDLERS�� �̸� ����, ����� �׸� �� �˻� ���� ó���⸦ �����ϴ� ATL ������Ʈ���� ������ �� ������
// �ش� ������Ʈ�� ���� �ڵ带 �����ϵ��� �� �ݴϴ�.
#ifndef SHARED_HANDLERS
#include "ParkYooJinR1.h"
#endif

#include "ParkYooJinR1Doc.h"
#include "ParkYooJinR1View.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CParkYooJinR1View

IMPLEMENT_DYNCREATE(CParkYooJinR1View, CView)

BEGIN_MESSAGE_MAP(CParkYooJinR1View, CView)
	// ǥ�� �μ� �����Դϴ�.
	ON_COMMAND(ID_FILE_PRINT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CParkYooJinR1View::OnFilePrintPreview)
	ON_WM_CONTEXTMENU()
	ON_WM_RBUTTONUP()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONDBLCLK()
	ON_WM_RBUTTONDOWN()
	ON_WM_KEYDOWN()
	ON_COMMAND(ID_LIGHTOFF, &CParkYooJinR1View::OnLightoff)
	ON_COMMAND(ID_LIGHTON, &CParkYooJinR1View::OnLighton)
	ON_COMMAND(ID_ORIGINALLIGHT, &CParkYooJinR1View::OnOriginallight)
	ON_COMMAND(ID_DAYSKY, &CParkYooJinR1View::OnDaysky)
	ON_COMMAND(ID_NIGHTSKY, &CParkYooJinR1View::OnNightsky)
	ON_UPDATE_COMMAND_UI(ID_DAYSKY, &CParkYooJinR1View::OnUpdateDaysky)
	ON_COMMAND(ID_SNOW, &CParkYooJinR1View::OnSnow)
	ON_COMMAND(ID_RAIN, &CParkYooJinR1View::OnRain)
	ON_COMMAND(ID_SUNNY, &CParkYooJinR1View::OnSunny)
//	ON_WM_MENUGETOBJECT()
	ON_WM_GETMINMAXINFO()
	ON_WM_DESTROY()
	ON_WM_TIMER()
	ON_WM_LBUTTONDOWN()
	ON_WM_ERASEBKGND()
END_MESSAGE_MAP()

// CParkYooJinR1View ����/�Ҹ�

CParkYooJinR1View::CParkYooJinR1View()
	:index(0)
{
	// TODO: ���⿡ ���� �ڵ带 �߰��մϴ�.

}

CParkYooJinR1View::~CParkYooJinR1View()
{
}

BOOL CParkYooJinR1View::PreCreateWindow(CREATESTRUCT& cs)
{
	cs.cy = 600;    
	cs.cx = 600; 

	cs.style &= ~WS_THICKFRAME;     //ũ�⸦ �÷ȴ� �ٷȴ��ϴ� ����� ��Ȱ��ȭ

	cs.style &= ~WS_MAXIMIZEBOX;    //�ִ�ȭ��ư ��Ȱ��ȭ

	return CView::PreCreateWindow(cs);
}

// CParkYooJinR1View �׸���
void CParkYooJinR1View::OnDraw(CDC* pDC)
{
	CParkYooJinR1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	CClientDC dc(this);
	
	if (!pDoc)
		return;
	
	//�ϴ� ����
	
	if(sky==1){
		CDC memdc;
		memdc.CreateCompatibleDC(pDC);

		CBitmap bitmap, *oldbitmap;
		bitmap.LoadBitmapW(IDB_BITMAP3);
		oldbitmap = memdc.SelectObject(&bitmap);

		BITMAP bmpinfo;
		bitmap.GetBitmap(&bmpinfo);
		memdc.SelectObject(&bitmap);

		BLENDFUNCTION bf;
		bf.BlendOp = AC_SRC_OVER;
		bf.BlendFlags = 0;
		bf.AlphaFormat = 0;

		pDC->BitBlt(0,0,bmpinfo.bmWidth,bmpinfo.bmHeight,&memdc,0,0,SRCCOPY);//���� ������

		memdc.SelectObject(oldbitmap);

	}
	else {
		CDC memdc;
		memdc.CreateCompatibleDC(pDC);

		CBitmap bitmap, *oldbitmap;
		bitmap.LoadBitmapW(IDB_BITMAP2);
		oldbitmap = memdc.SelectObject(&bitmap);

		BITMAP bmpinfo;
		bitmap.GetBitmap(&bmpinfo);
		memdc.SelectObject(&bitmap);

		BLENDFUNCTION bf;
		bf.BlendOp = AC_SRC_OVER;
		bf.BlendFlags = 0;
		bf.AlphaFormat = 0;

		pDC->BitBlt(0,0,bmpinfo.bmWidth,bmpinfo.bmHeight,&memdc,0,0,SRCCOPY);//���� ������

		memdc.SelectObject(oldbitmap);
	}
	
	
	//backGround(pDC);
	// TODO: ���⿡ ���� �����Ϳ� ���� �׸��� �ڵ带 �߰��մϴ�.
	//house(pDC);
	building(pDC);
	brownWall(pDC);
	stair(pDC);
	COLORREF color = RGB(142,199,255);
	windows(pDC,color);
	outLines(pDC);
	
	//���� ����
	if(light==0){
		COLORREF color =RGB(0,0,0);
		windows(pDC,color);
	
	}
	else if(light==1){
		
		COLORREF color =RGB(255,255,79);
		windows(pDC,color);
	}
	else{
		COLORREF color = RGB(142,199,255);
		windows(pDC,color);
	}
	//��-�����̽���
	if(star==1){
	//��&��
	CClientDC dc(this);
	CPen penStar, *pPenStar;
	penStar.CreatePen(PS_SOLID,3,RGB(255,242,0));
	pPenStar = (CPen*)dc.SelectObject(&penStar);
	CBrush brushStar, *pBrushStar;
	brushStar.CreateSolidBrush(RGB(255,242,0));
	pBrushStar = (CBrush*)dc.SelectObject(&brushStar);
	POINT Star[] = {{59,166},{67,178},{80,173},{74,193},{80,207},{70,203},{61,215},{58,196},{47,188},{57,181}};
	dc.Polygon(Star, 10);
	POINT Star2[] = {{127,82},{139,92},{149,88},{145,98},{154,116},{139,112},{127,127},{129,115},{116,106},{129,99}};
	dc.Polygon(Star2, 10);
	POINT Star3[] = {{232,83},{237,93},{248,93},{242,104},{244,114},{236,111},{222,123},{225,109},{210,106},{226,99}};
	dc.Polygon(Star3, 10);
	POINT Star4[] = {{356,23},{365,30},{376,24},{372,35},{380,49},{367,46},{363,57},{358,46},{346,42},{356,36}};
	dc.Polygon(Star4, 10);
	POINT Star5[] = {{445, 78}, {458, 43}, {471, 75}, {438, 54}, {468, 51}, {445, 78}, };
	dc.Polygon(Star5, 6);
	POINT Star6[] = {{458,43},{463,51},{471,52},{467,56},{470,74},{456,66},{445,77},{450,63},{439,55},{454,54}};
	dc.Polygon(Star6, 10);
	POINT Star7[] = {{645,38},{649,47},{660,47},{651,55},{653,70},{642,61},{628,70},{636,58},{627,50},{639,49}};
	dc.Polygon(Star7, 10);
	POINT Star8[] = { {675,95},{671,105},{682,108},{669,115},{664,129},{657,119},{645,124},{655,113},{646,98},{665,103}};
	dc.Polygon(Star8, 10);
	POINT Star9[] = {{741,63},{748,74},{757,72},{754,85},{758,98},{750,95},{747,108},{744,92},{729,85},{741,77}};
	dc.Polygon(Star9, 10);
	
	dc.SelectObject(pPenStar);
	dc.SelectObject(pBrushStar);
	//��
	CPen pen_moon;
	pen_moon.CreatePen(PS_SOLID,2,RGB(255,242,0));
	CPen *pPen=pDC->SelectObject(&pen_moon);
	CBrush brush_moon;
	brush_moon.CreateSolidBrush(RGB(255,242,0));
	CBrush *pBrush=pDC->SelectObject(&brush_moon);

	int p_int_mo[][2] = {{1090,30},{1110,35},{1130,46},{1140,59},{1143,73},{1142,95},{1134,111},
	{1122,123},{1109,127},{1085,128},{1068,124},{1056,114},{1050,105},{1067,111},{1087,109},{1097,105},
	{1108,91},{1110,84},{1110,75},{1105,66},{1098,59},{1089,52},{1076,39},{1073,42},{1059,41},{1052,43}};
	CPoint p_mo[26];
	for(int i=0;i<sizeof(p_int_mo)/sizeof(int[2]);i++){
		p_mo[i].x=p_int_mo[i][0];
		p_mo[i].y=p_int_mo[i][1];
	}
	pDC->Polygon(p_mo,26);

	}
	
}


// CParkYooJinR1View �μ�


void CParkYooJinR1View::OnFilePrintPreview()
{
#ifndef SHARED_HANDLERS
	AFXPrintPreview(this);
#endif
}

BOOL CParkYooJinR1View::OnPreparePrinting(CPrintInfo* pInfo)
{
	// �⺻���� �غ�
	return DoPreparePrinting(pInfo);
}

void CParkYooJinR1View::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: �μ��ϱ� ���� �߰� �ʱ�ȭ �۾��� �߰��մϴ�.
}

void CParkYooJinR1View::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: �μ� �� ���� �۾��� �߰��մϴ�.
}

void CParkYooJinR1View::OnRButtonUp(UINT /* nFlags */, CPoint point)
{
	ClientToScreen(&point);
	OnContextMenu(this, point);
}

void CParkYooJinR1View::OnContextMenu(CWnd* /* pWnd */, CPoint point)
{
#ifndef SHARED_HANDLERS
	theApp.GetContextMenuManager()->ShowPopupMenu(IDR_POPUP_EDIT, point.x, point.y, this, TRUE);
#endif
}


// CParkYooJinR1View ����

#ifdef _DEBUG
void CParkYooJinR1View::AssertValid() const
{
	CView::AssertValid();
}

void CParkYooJinR1View::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CParkYooJinR1Doc* CParkYooJinR1View::GetDocument() const // ����׵��� ���� ������ �ζ������� �����˴ϴ�.
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CParkYooJinR1Doc)));
	return (CParkYooJinR1Doc*)m_pDocument;
}
#endif //_DEBUG


// CParkYooJinR1View �޽��� ó����


void CParkYooJinR1View::house(CDC* pDC)
{
	CDC MemDC;
   BITMAP bmpInfo;

   MemDC.CreateCompatibleDC(pDC);

   CBitmap bmp;
   CBitmap* pOldBmp = NULL;

   bmp.LoadBitmap(IDB_BITMAP1);
   bmp.GetBitmap(&bmpInfo);

   MemDC.SelectObject(&bmp);
   pDC->BitBlt( 0, 0, bmpInfo.bmWidth, bmpInfo.bmHeight, &MemDC, 0, 0, SRCCOPY ); 

}


void CParkYooJinR1View::OnLButtonDblClk(UINT nFlags, CPoint point)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
//	CClientDC dc(this);
//	string str="output_"+ to_string(++index)+".txt";
//	CString cStr((str+"�������!").c_str());

//	file.open(str);
//	for(vector<CString>::iterator num = vt.begin(); num<vt.end() ; num++)
//		file <<(LPCTSTR)*num;
//	file.close();
//	dc.TextOut(point.x,point.y,cStr);
//	vt.clear();

	CView::OnLButtonDblClk(nFlags, point);
}

//���
void CParkYooJinR1View::stair(CDC * pDC)
{
		//��� �պκ�
	CPen pen1;
	pen1.CreatePen(PS_SOLID,1,RGB(105,83,72));
	CPen *pPen=pDC->SelectObject(&pen1);
	CBrush brush1;
	brush1.CreateSolidBrush(RGB(105,83,72));
	CBrush *pBrush=pDC->SelectObject(&brush1);

	int p_int1[][2] = {{317,438}, {657,422},{657,429},{317,446}};
	CPoint p1[4];
	for(int i=0;i<sizeof(p_int1)/sizeof(int[2]);i++){
		p1[i].x=p_int1[i][0];
		p1[i].y=p_int1[i][1];
	}
	pDC->Polygon(p1,4);
	int p_int2[][2] = {{325,425},{648,414},{648,418},{325,433}};
	CPoint p2[4];
	for(int i=0;i<sizeof(p_int2)/sizeof(int[2]);i++){
		p2[i].x=p_int2[i][0];
		p2[i].y=p_int2[i][1];
	}
	pDC->Polygon(p2,4);

	int p_int3[][2] = {{334,413},{637,406},{637,411},{334,420}};
	CPoint p3[4];
	for(int i=0;i<sizeof(p_int3)/sizeof(int[2]);i++){
		p3[i].x=p_int3[i][0];
		p3[i].y=p_int3[i][1];
	}
	pDC->Polygon(p3,4);
	
	pDC->SelectObject(pPen);
	pDC->SelectObject(pBrush);

	//��� ���κ�(��ο� ��)
	CPen pen2(PS_SOLID,1,RGB(64,51,42));
	pPen=pDC->SelectObject(&pen2);
	CBrush brush2(RGB(64,51,42));
	pBrush=pDC->SelectObject(&brush2);

	int p_int4[][2] = {{317,447}, {248,435},{248,426},{317,438}};
	CPoint p4[4];
	for(int i=0;i<sizeof(p_int4)/sizeof(int[2]);i++){
		p4[i].x=p_int4[i][0];
		p4[i].y=p_int4[i][1];
	}
	pDC->Polygon(p4,4);

	int p_int5[][2] = {{324,425}, {324,433},{261,424},{261,417}};
	CPoint p5[4];
	for(int i=0;i<sizeof(p_int5)/sizeof(int[2]);i++){
		p5[i].x=p_int5[i][0];
		p5[i].y=p_int5[i][1];
	}
	pDC->Polygon(p5,4);
	
	int p_int6[][2] = {{334,413}, {334,419},{274,414},{274,407}};
	CPoint p6[4];
	for(int i=0;i<sizeof(p_int6)/sizeof(int[2]);i++){
		p6[i].x=p_int6[i][0];
		p6[i].y=p_int6[i][1];
	}
	pDC->Polygon(p6,4);
	pDC->SelectObject(pPen);
	pDC->SelectObject(pBrush);
	
	//��� ����
	CPen pen3(PS_SOLID,1,RGB(213,187,164));
	pPen=pDC->SelectObject(&pen3);
	CBrush brush3(RGB(213,187,164));
	pBrush=pDC->SelectObject(&brush3);

	int p_int7[][2] = {{261,424},{325,433},{648,419},{657,422},{317,438},{248,426}};
	CPoint p7[6];
	for(int i=0;i<sizeof(p_int7)/sizeof(int[2]);i++){
		p7[i].x=p_int7[i][0];
		p7[i].y=p_int7[i][1];
	}
	pDC->Polygon(p7,6);
	
	int p_int8[][2] = {{274,413},{334,420},{637,410},{648,414},{325,425},{261,417}};
	CPoint p8[6];
	for(int i=0;i<sizeof(p_int8)/sizeof(int[2]);i++){
		p8[i].x=p_int8[i][0];
		p8[i].y=p_int8[i][1];
	}
	pDC->Polygon(p8,6);
	
	int p_int9[][2] = {{275,406},{560,403},{637,405},{333,414}};
	CPoint p9[4];
	for(int i=0;i<sizeof(p_int9)/sizeof(int[2]);i++){
		p9[i].x=p_int9[i][0];
		p9[i].y=p_int9[i][1];
	}
	pDC->Polygon(p9,4);

	pDC->SelectObject(pPen);
	pDC->SelectObject(pBrush);
	
}
void CParkYooJinR1View::brownWall(CDC* pDC)
{
	//��
	CPen pen4(PS_SOLID,2,RGB(102,87,84));
	CPen *pPen=pDC->SelectObject(&pen4);
	CBrush brush4(RGB(102,87,84));
	CBrush *pBrush=pDC->SelectObject(&brush4);
	
	int p_int10[][2] = {{277,110},{470,148},{470,169},{295,135},{295,251},{683,278},{683,295},{701,404},{701,420},{688,422},{688,404},{668,296},{277,273}};
	CPoint p10[13];
	for(int i=0;i<sizeof(p_int10)/sizeof(int[2]);i++){
		p10[i].x=p_int10[i][0];
		p10[i].y=p_int10[i][1];
	}
	pDC->Polygon(p10,13);
	
	pDC->SelectObject(pPen);
	pDC->SelectObject(pBrush);

	
	//2�� ��
	CPen pen5(PS_SOLID,2,RGB(72,59,52));
	pPen=pDC->SelectObject(&pen5);
	CBrush brush5(RGB(72,59,52));
	pBrush=pDC->SelectObject(&brush5);
	int p_int11[][2] = {{242,149},{277,110},{277,273},{242,288}};
	CPoint p11[4];
	for(int i=0;i<sizeof(p_int11)/sizeof(int[2]);i++){
		p11[i].x=p_int11[i][0];
		p11[i].y=p_int11[i][1];
	}
	pDC->Polygon(p11,4);
	
	pDC->SelectObject(pPen);
	pDC->SelectObject(pBrush);
	
	//2��õ��
	CPen pen6(PS_SOLID,2,RGB(42,32,30));
	pPen=pDC->SelectObject(&pen6);
	CBrush brush6(RGB(42,32,30));
	pBrush=pDC->SelectObject(&brush6);

	int p_int12[][2] = {{297,135},{470,169},{442,183},{442,169},{297,149}};
	CPoint p12[5];
	for(int i=0;i<sizeof(p_int12)/sizeof(int[2]);i++){
		p12[i].x=p_int12[i][0];
		p12[i].y=p_int12[i][1];
	}
	pDC->Polygon(p12,5);

	pDC->SelectObject(pPen);
	pDC->SelectObject(pBrush);

	//1�� ��
	CPen pen7(PS_SOLID,2,RGB(47,37,35));
	pPen=pDC->SelectObject(&pen7);
	CBrush brush7(RGB(47,37,35));
	pBrush=pDC->SelectObject(&brush7);
	int p_int13[][2] = {{618,302},{669,295},{687,404},{687,419},{648,419},{648,412},{637,411},{637,402},{614,401},{614,314},{618,314}};
	CPoint p13[11];
	for(int i=0;i<sizeof(p_int13)/sizeof(int[2]);i++){
		p13[i].x=p_int13[i][0];
		p13[i].y=p_int13[i][1];
	}
	pDC->Polygon(p13,11);

	int p_int62[][2] = {{700,422},{701,426},{690,430},{658,428},{658,422},{650,420},{685,420},{684,422},{689,422}};
	CPoint p62[9];
	for(int i=0;i<sizeof(p_int62)/sizeof(int[2]);i++){
		p62[i].x=p_int62[i][0];
		p62[i].y=p_int62[i][1];
	}
	pDC->Polygon(p62,9);

	pDC->SelectObject(pPen);
	pDC->SelectObject(pBrush);
	
	//1�� õ��
	CPen pen8(PS_SOLID,2,RGB(46,39,31));
	pPen=pDC->SelectObject(&pen8);
	CBrush brush8(RGB(47,37,35));
	pBrush=pDC->SelectObject(&brush8);

	int p_int14[][2] = {{277,274},{668,296},{617,302},{274,280},{251,291},{241,289}};
	CPoint p14[6];
	for(int i=0;i<sizeof(p_int14)/sizeof(int[2]);i++){
		p14[i].x=p_int14[i][0];
		p14[i].y=p_int14[i][1];
	}
	pDC->Polygon(p14,6);

	pDC->SelectObject(pPen);
	pDC->SelectObject(pBrush);
}

void CParkYooJinR1View::building(CDC* pDC)
{
	//1�� -��(����)
	CPen pen9(PS_SOLID,2,RGB(235,232,227));
	CPen *pPen=pDC->SelectObject(&pen9);
	CBrush brush9(RGB(235,232,227));
	CBrush *pBrush=pDC->SelectObject(&brush9);

	int p_int15[][2] = {{275,280},{618,302},{617,313},{559,310},{560,403},{274,406}};
	CPoint p15[6];
	for(int i=0;i<sizeof(p_int15)/sizeof(int[2]);i++){
		p15[i].x=p_int15[i][0];
		p15[i].y=p_int15[i][1];
	}
	pDC->Polygon(p15,6);

	pDC->SelectObject(pPen);
	pDC->SelectObject(pBrush);
	
	//1��-��(����)
	CPen pen10(PS_SOLID,2,RGB(175,172,167));
	pDC->SelectObject(&pen10);
	CBrush brush10(RGB(175,172,167));
	pDC->SelectObject(&brush10);

	int p_int16[][2] = {{274,279},{273,406},{238,404},{238,317},{248,313},{248,291}};
	CPoint p16[6];
	for(int i=0;i<sizeof(p_int16)/sizeof(int[2]);i++){
		p16[i].x=p_int16[i][0];
		p16[i].y=p_int16[i][1];
	}
	pDC->Polygon(p16,6);

	pDC->SelectObject(pPen);
	pDC->SelectObject(pBrush);
	//1�� ����-(������ ���ϴ� ��)
	CPen pen11(PS_SOLID,2,RGB(117,114,107));
	pDC->SelectObject(&pen11);
	CBrush brush11(RGB(117,114,107));
	pDC->SelectObject(&brush11);

	int p_int17[][2] = {{560,310},{618,312},{561,323}};
	CPoint p17[3];
	for(int i=0;i<sizeof(p_int17)/sizeof(int[2]);i++){
		p17[i].x=p_int17[i][0];
		p17[i].y=p_int17[i][1];
	}
	pDC->Polygon(p17,3);

	pDC->SelectObject(pPen);
	pDC->SelectObject(pBrush);

	
	//1�� ���� (������)
	CPen pen12(PS_SOLID,2,RGB(229,228,223));
	pDC->SelectObject(&pen12);
	CBrush brush12(RGB(229,228,223));
	pDC->SelectObject(&brush12);

	int p_int18[][2] = {{441,241},{629,260},{628,272},{442,260}};
	CPoint p18[4];
	for(int i=0;i<sizeof(p_int18)/sizeof(int[2]);i++){
		p18[i].x=p_int18[i][0];
		p18[i].y=p_int18[i][1];
	}
	pDC->Polygon(p18,4);
	pDC->SelectObject(pPen);
	pDC->SelectObject(pBrush);

	//2�� ���� �ǹ� ����
	CPen pen13(PS_SOLID,2,RGB(235,232,227));
	pDC->SelectObject(&pen13);
	CBrush brush13(RGB(235,232,227));
	pDC->SelectObject(&brush13);

	int p_int19[][2] = {{442,195},{546,209},{546,250},{442,240}};
	CPoint p19[4];
	for(int i=0;i<sizeof(p_int19)/sizeof(int[2]);i++){
		p19[i].x=p_int19[i][0];
		p19[i].y=p_int19[i][1];
	}
	pDC->Polygon(p19,4);
	pDC->SelectObject(pPen);
	pDC->SelectObject(pBrush);
	//2�� �߾� �ǹ� ����
	
	CPen pen14(PS_SOLID,2,RGB(235,232,227));
	pDC->SelectObject(&pen14);
	CBrush brush14(RGB(235,232,227));
	pDC->SelectObject(&brush14);

	int p_int20[][2] = {{274,77},{440,108},{439,140},{278,108},{275,112}};
	CPoint p20[5];
	for(int i=0;i<sizeof(p_int20)/sizeof(int[2]);i++){
		p20[i].x=p_int20[i][0];
		p20[i].y=p_int20[i][1];
	}
	pDC->Polygon(p20,5);
	pDC->SelectObject(pPen);
	pDC->SelectObject(pBrush);
	
	//2�� �߾� ��������
	CPen pen15(PS_SOLID,2,RGB(190,187,182));
	pDC->SelectObject(&pen15);
	CBrush brush15(RGB(190,187,182));
	pDC->SelectObject(&brush15);

	int p_int21[][2] = {{198,171},{273,77},{273,112},{241,149},{241,237},{223,237},{223,206},{215,213},
	{215,236},{201,235},{199,222},{226,196},{227,170},{212,186},{207,186},{199,194}};
	CPoint p21[16];
	for(int i=0;i<sizeof(p_int21)/sizeof(int[2]);i++){
		p21[i].x=p_int21[i][0];
		p21[i].y=p_int21[i][1];
	}
	pDC->Polygon(p21,16);
	pDC->SelectObject(pPen);
	pDC->SelectObject(pBrush);

	//2�� ���� ����
	CPen pen16(PS_SOLID,2,RGB(230,227,222));
	pDC->SelectObject(&pen16);
	CBrush brush16(RGB(230,227,222));
	pDC->SelectObject(&brush16);

	int p_int22[][2] = {{99,228},{240,240},{240,290},{247,289},{246,312},{109,306},{109,432},{99,432}};
	CPoint p22[8];
	for(int i=0;i<sizeof(p_int22)/sizeof(int[2]);i++){
		p22[i].x=p_int22[i][0];
		p22[i].y=p_int22[i][1];
	}
	pDC->Polygon(p22,8);
	pDC->SelectObject(pPen);
	pDC->SelectObject(pBrush);

	
	//1�� ���� ��������
	CPen pen17(PS_SOLID,2,RGB(189,186,181));
	pDC->SelectObject(&pen17);
	CBrush brush17(RGB(189,186,181));
	pDC->SelectObject(&brush17);

	int p_int23[][2] = {{76,277},{97,228},{97,432},{77,427}};
	CPoint p23[4];
	for(int i=0;i<sizeof(p_int23)/sizeof(int[2]);i++){
		p23[i].x=p_int23[i][0];
		p23[i].y=p_int23[i][1];
	}
	pDC->Polygon(p23,4);
	pDC->SelectObject(pPen);
	pDC->SelectObject(pBrush);
	
	//1�� ���� �� õ��
	CPen pen18(PS_SOLID,2,RGB(205,206,200));
	pDC->SelectObject(&pen18);
	CBrush brush18(RGB(205,206,200));
	pDC->SelectObject(&brush18);

	int p_int24[][2] = {{110,308},{236,313},{235,423},{231,423},{232,405},{110,405}};
	CPoint p24[6];
	for(int i=0;i<sizeof(p_int24)/sizeof(int[2]);i++){
		p24[i].x=p_int24[i][0];
		p24[i].y=p_int24[i][1];
	}
	pDC->Polygon(p24,6);
	pDC->SelectObject(pPen);
	pDC->SelectObject(pBrush);
	
	
	//�߾Ӱǹ� ��������Ʒ� 
	CPen pen19(PS_SOLID,2,RGB(37,37,35));
	pDC->SelectObject(&pen19);
	CBrush brush19(RGB(37,37,35));
	pDC->SelectObject(&brush19);

	int p_int25[][2] = {{274,406},{274,412},{261,417},{261,422},{246,424},{248,431},{238,431},{237,406}};
	CPoint p25[8];
	for(int i=0;i<sizeof(p_int25)/sizeof(int[2]);i++){
		p25[i].x=p_int25[i][0];
		p25[i].y=p_int25[i][1];
	}
	pDC->Polygon(p25,8);
	pDC->SelectObject(pPen);
	pDC->SelectObject(pBrush);
	
	//���ʰǹ� �߾� ���� �Ʒ�
	CPen pen20(PS_SOLID,2,RGB(52,52,52));
	pDC->SelectObject(&pen20);
	CBrush brush20(RGB(52,52,52));
	pDC->SelectObject(&brush20);

	int p_int26[][2] = {{110,406},{229,406},{229,424},{236,424},{236,431},{110,431}};
	CPoint p26[6];
	for(int i=0;i<sizeof(p_int26)/sizeof(int[2]);i++){
		p26[i].x=p_int26[i][0];
		p26[i].y=p_int26[i][1];
	}
	pDC->Polygon(p26,6);
	pDC->SelectObject(pPen);
	pDC->SelectObject(pBrush);

	//2�� �߾� �ǹ� ����	
	CPen pen21(PS_SOLID,2,RGB(196,170,143));
	pDC->SelectObject(&pen21);
	CBrush brush21(RGB(196,170,143));
	pDC->SelectObject(&brush21);

	int p_int27[][2] = {{293,149},{440,171},{440,261},{293,252}};
	CPoint p27[4];
	for(int i=0;i<sizeof(p_int27)/sizeof(int[2]);i++){
		p27[i].x=p_int27[i][0];
		p27[i].y=p_int27[i][1];
	}
	pDC->Polygon(p27,4);
	pDC->SelectObject(pPen);
	pDC->SelectObject(pBrush);
	
	//2�� �� ���� ����
	CPen pen22(PS_SOLID,2,RGB(161,158,151));
	pDC->SelectObject(&pen22);
	CBrush brush22(RGB(161,158,151));
	pDC->SelectObject(&brush22);

	int p_int28[][2] = {{225,186},{224,196},{212,194},{186,221},{185,221},{186,218},{183,216},{208,187}};
	CPoint p28[8];
	for(int i=0;i<sizeof(p_int28)/sizeof(int[2]);i++){
		p28[i].x=p_int28[i][0];
		p28[i].y=p_int28[i][1];
	}
	pDC->Polygon(p28,8);
	pDC->SelectObject(pPen);
	pDC->SelectObject(pBrush);

	//2�� �� ��
	CPen pen23(PS_SOLID,1,RGB(49,53,54));
	pDC->SelectObject(&pen23);
	CBrush brush23(RGB(91,97,93));
	pDC->SelectObject(&brush23);

	int p_int29[][2] = {{215,214},{221,208},{221,236},{215,236}};
	CPoint p29[4];
	for(int i=0;i<sizeof(p_int29)/sizeof(int[2]);i++){
		p29[i].x=p_int29[i][0];
		p29[i].y=p_int29[i][1];
	}
	pDC->Polygon(p29,4);
	pDC->SelectObject(pPen);
	pDC->SelectObject(pBrush);

	//1�� ���� �Ʒ�����
	CPen pen24(PS_SOLID,1,RGB(238,235,230));
	pDC->SelectObject(&pen24);
	CBrush brush24(RGB(238,235,230));
	pDC->SelectObject(&brush24);

	int p_int30[][2] = {{560,324},{612,315},{612,342},{561,340}};
	CPoint p30[4];
	for(int i=0;i<sizeof(p_int30)/sizeof(int[2]);i++){
		p30[i].x=p_int30[i][0];
		p30[i].y=p_int30[i][1];
	}
	pDC->Polygon(p30,4);
	pDC->SelectObject(pPen);
	pDC->SelectObject(pBrush);
	
	//2�� ���� ������
	CPen pen25(PS_SOLID,1,RGB(99,93,95));
	pDC->SelectObject(&pen25);
	CBrush brush25(RGB(99,93,95));
	pDC->SelectObject(&brush25);

	int p_int31[][2] = {{183,215},{207,188},{211,191},{186,218},{185,217}};
	CPoint p31[5];
	for(int i=0;i<sizeof(p_int31)/sizeof(int[2]);i++){
		p31[i].x=p_int31[i][0];
		p31[i].y=p_int31[i][1];
	}
	pDC->Polygon(p31,5);
	pDC->SelectObject(pPen);
	pDC->SelectObject(pBrush);
	
	//���� �ǹ� ���� ����
	
	CPen pen26(PS_SOLID,1,RGB(97,96,92));
	pDC->SelectObject(&pen26);
	CBrush brush26(RGB(97,96,92));
	pDC->SelectObject(&brush26);

	int p_int32[][2] = {{612,343},{612,402},{561,402},{561,341}};
	CPoint p32[4];
	for(int i=0;i<sizeof(p_int32)/sizeof(int[2]);i++){
		p32[i].x=p_int32[i][0];
		p32[i].y=p_int32[i][1];
	}
	pDC->Polygon(p32,4);
	pDC->SelectObject(pPen);
	pDC->SelectObject(pBrush);
	
	//2�� ���� �ظ�
	
	CPen pen27(PS_SOLID,1,RGB(94,93,89));
	pDC->SelectObject(&pen27);
	CBrush brush27(RGB(94,93,89));
	pDC->SelectObject(&brush27);

	int p_int33[][2] = {{188,221},{212,196},{224,197},{197,222}};
	CPoint p33[4];
	for(int i=0;i<sizeof(p_int33)/sizeof(int[2]);i++){
		p33[i].x=p_int33[i][0];
		p33[i].y=p_int33[i][1];
	}
	pDC->Polygon(p33,4);
	pDC->SelectObject(pPen);
	pDC->SelectObject(pBrush);
	
	//2�� ���� ��� ��
	CPen pen29(PS_SOLID,1,RGB(224,225,227));
	pDC->SelectObject(&pen29);
	CBrush brush29(RGB(224,225,227));
	pDC->SelectObject(&brush29);

	int p_int55[][2] = {{312,161},{409,175},{409,259},{312,253}};
	CPoint p55[4];
	for(int i=0;i<sizeof(p_int55)/sizeof(int[2]);i++){
		p55[i].x=p_int55[i][0];
		p55[i].y=p_int55[i][1];
	}
	pDC->Polygon(p55,4);
	pDC->SelectObject(pPen);
	pDC->SelectObject(pBrush);
	
	CPen pen30(PS_SOLID,1,RGB(65,64,62));
	pDC->SelectObject(&pen30);
	CBrush brush30(RGB(65,64,62));
	pDC->SelectObject(&brush30);

	int p_int60[][2] = {{237,312},{246,313},{237,316}};
	CPoint p60[3];
	for(int i=0;i<sizeof(p_int60)/sizeof(int[2]);i++){
		p60[i].x=p_int60[i][0];
		p60[i].y=p_int60[i][1];
	}
	pDC->Polygon(p60,3);
	pDC->SelectObject(pPen);
	pDC->SelectObject(pBrush);


}


void CParkYooJinR1View::windows(CDC* pDC,COLORREF color)
{
	//1��-â
	
	CPen pen28(PS_SOLID,2,color);
	CPen *pPen=pDC->SelectObject(&pen28);
	CBrush brush28(color);
	CBrush *pBrush=pDC->SelectObject(&brush28);

	int p_int34[][2] = {{449,396},{449,322},{502,324},{502,396}};
	CPoint p34[4];
	for(int i=0;i<sizeof(p_int34)/sizeof(int[2]);i++){
		p34[i].x=p_int34[i][0];
		p34[i].y=p_int34[i][1];
	}
	pDC->Polygon(p34,4);

	int p_int35[][2] = {{532,326},{532,396},{507,396},{506,324}};
	CPoint p35[4];
	for(int i=0;i<sizeof(p_int35)/sizeof(int[2]);i++){
		p35[i].x=p_int35[i][0];
		p35[i].y=p_int35[i][1];
	}
	pDC->Polygon(p35,4);
	
	int p_int36[][2] = {{415,319},{415,342},{400,343},{400,317}};
	CPoint p36[4];
	for(int i=0;i<sizeof(p_int36)/sizeof(int[2]);i++){
		p36[i].x=p_int36[i][0];
		p36[i].y=p_int36[i][1];
	}
	pDC->Polygon(p36,4);
		
	int p_int37[][2] = {{415,349},{415,368},{400,367},{400,348}};
	CPoint p37[4];
	for(int i=0;i<sizeof(p_int37)/sizeof(int[2]);i++){
		p37[i].x=p_int37[i][0];
		p37[i].y=p_int37[i][1];
	}
	pDC->Polygon(p37,4);
	
	int p_int38[][2] = {{415,374},{415,398},{400,397},{400,374}};
	CPoint p38[4];
	for(int i=0;i<sizeof(p_int38)/sizeof(int[2]);i++){
		p38[i].x=p_int38[i][0];
		p38[i].y=p_int38[i][1];
	}
	pDC->Polygon(p38,4);

	int p_int39[][2] = {{369,317},{369,340},{353,339},{353,315}};
	CPoint p39[4];
	for(int i=0;i<sizeof(p_int39)/sizeof(int[2]);i++){
		p39[i].x=p_int39[i][0];
		p39[i].y=p_int39[i][1];
	}
	pDC->Polygon(p39,4);

	int p_int40[][2] = {{369,347},{369,367},{353,366},{353,346}};
	CPoint p40[4];
	for(int i=0;i<sizeof(p_int40)/sizeof(int[2]);i++){
		p40[i].x=p_int40[i][0];
		p40[i].y=p_int40[i][1];
	}
	pDC->Polygon(p40,4);

	int p_int41[][2] = {{369,372},{369,397},{353,397},{353,373}};
	CPoint p41[4];
	for(int i=0;i<sizeof(p_int41)/sizeof(int[2]);i++){
		p41[i].x=p_int41[i][0];
		p41[i].y=p_int41[i][1];
	}
	pDC->Polygon(p41,4);
	int p_int42[][2] = {{320,316},{320,339},{302,338},{302,314}};
	CPoint p42[4];
	for(int i=0;i<sizeof(p_int42)/sizeof(int[2]);i++){
		p42[i].x=p_int42[i][0];
		p42[i].y=p_int42[i][1];
	}
	pDC->Polygon(p42,4);

	int p_int43[][2] = {{320,346},{320,366},{302,366},{302,345}};
	CPoint p43[4];
	for(int i=0;i<sizeof(p_int43)/sizeof(int[2]);i++){
		p43[i].x=p_int43[i][0];
		p43[i].y=p_int43[i][1];
	}
	pDC->Polygon(p43,4);

	int p_int44[][2] = {{320,373},{320,397},{302,396},{303,373}};
	CPoint p44[4];
	for(int i=0;i<sizeof(p_int44)/sizeof(int[2]);i++){
		p44[i].x=p_int44[i][0];
		p44[i].y=p_int44[i][1];
	}
	pDC->Polygon(p44,4);

	int p_int45[][2] = {{219,325},{219,389},{199,389},{198,323}};
	CPoint p45[4];
	for(int i=0;i<sizeof(p_int45)/sizeof(int[2]);i++){
		p45[i].x=p_int45[i][0];
		p45[i].y=p_int45[i][1];
	}
	pDC->Polygon(p45,4);
	
	int p_int46[][2] = {{195,323},{195,389},{151,389},{151,321}};
	CPoint p46[4];
	for(int i=0;i<sizeof(p_int46)/sizeof(int[2]);i++){
		p46[i].x=p_int46[i][0];
		p46[i].y=p_int46[i][1];
	}
	pDC->Polygon(p46,4);
	
	int p_int47[][2] = {{147,321},{147,389},{125,388},{125,319}};
	CPoint p47[4];
	for(int i=0;i<sizeof(p_int47)/sizeof(int[2]);i++){
		p47[i].x=p_int47[i][0];
		p47[i].y=p_int47[i][1];
	}
	pDC->Polygon(p47,4);
	
	int p_int48[][2] = {{521,242},{521,247},{510,246},{510,240}};
	CPoint p48[4];
	for(int i=0;i<sizeof(p_int48)/sizeof(int[2]);i++){
		p48[i].x=p_int48[i][0];
		p48[i].y=p_int48[i][1];
	}
	pDC->Polygon(p48,4);
	
	int p_int49[][2] = {{507,241},{507,245},{496,244},{496,239}};
	CPoint p49[4];
	for(int i=0;i<sizeof(p_int49)/sizeof(int[2]);i++){
		p49[i].x=p_int49[i][0];
		p49[i].y=p_int49[i][1];
	}
	pDC->Polygon(p49,4);
	
	int p_int50[][2] = {{493,239},{492,244},{482,243},{482,237}};
	CPoint p50[4];
	for(int i=0;i<sizeof(p_int50)/sizeof(int[2]);i++){
		p50[i].x=p_int50[i][0];
		p50[i].y=p_int50[i][1];
	}
	pDC->Polygon(p50,4);

	int p_int51[][2] = {{405,178},{405,216},{348,210},{348,171}};
	CPoint p51[4];
	for(int i=0;i<sizeof(p_int51)/sizeof(int[2]);i++){
		p51[i].x=p_int51[i][0];
		p51[i].y=p_int51[i][1];
	}
	pDC->Polygon(p51,4);
	
	int p_int52[][2] = {{405,222},{405,257},{348,253},{348,216}};
	CPoint p52[4];
	for(int i=0;i<sizeof(p_int52)/sizeof(int[2]);i++){
		p52[i].x=p_int52[i][0];
		p52[i].y=p_int52[i][1];
	}
	pDC->Polygon(p52,4);
	
	int p_int53[][2] = {{340,215},{340,253},{317,251},{317,213}};
	CPoint p53[4];
	for(int i=0;i<sizeof(p_int53)/sizeof(int[2]);i++){
		p53[i].x=p_int53[i][0];
		p53[i].y=p_int53[i][1];
	}
	pDC->Polygon(p53,4);
	
	int p_int54[][2] = {{340,171},{340,205},{317,203},{317,168}};
	CPoint p54[4];
	for(int i=0;i<sizeof(p_int54)/sizeof(int[2]);i++){
		p54[i].x=p_int54[i][0];
		p54[i].y=p_int54[i][1];
	}
	pDC->Polygon(p54,4);
	
	int p_int56[][2] = {{253,179},{253,202},{250,205},{250,183}};
	CPoint p56[4];
	for(int i=0;i<sizeof(p_int56)/sizeof(int[2]);i++){
		p56[i].x=p_int56[i][0];
		p56[i].y=p_int56[i][1];
	}
	pDC->Polygon(p56,4);
	
	int p_int57[][2] = {{253,208},{253,223},{250,226},{250,211}};
	CPoint p57[4];
	for(int i=0;i<sizeof(p_int57)/sizeof(int[2]);i++){
		p57[i].x=p_int57[i][0];
		p57[i].y=p_int57[i][1];
	}
	pDC->Polygon(p57,4);

	int p_int58[][2] = {{253,231},{253,250},{250,254},{250,232}};
	CPoint p58[4];
	for(int i=0;i<sizeof(p_int58)/sizeof(int[2]);i++){
		p58[i].x=p_int58[i][0];
		p58[i].y=p_int58[i][1];
	}
	pDC->Polygon(p58,4);
	
	int p_int59[][2] = {{215,185},{225,174},{225,185}};
	CPoint p59[3];
	for(int i=0;i<sizeof(p_int59)/sizeof(int[2]);i++){
		p59[i].x=p_int59[i][0];
		p59[i].y=p_int59[i][1];
	}
	pDC->Polygon(p59,3);

	pDC->SelectObject(pPen);
	pDC->SelectObject(pBrush);
}


void CParkYooJinR1View::outLines(CDC* pDC)
{
	CClientDC dc(this);

	CPen penL1;
	penL1.CreatePen(PS_SOLID,3,RGB(71,61,52));
	CPen* oldPen =dc.SelectObject(&penL1);
	dc.MoveTo(242,150);dc.LineTo(276,110);
	dc.LineTo(471,149);dc.LineTo(471,168);dc.LineTo(441,181);	
	dc.MoveTo(250,291);	dc.LineTo(242,290);dc.LineTo(277,274);
	dc.LineTo(669,296);	dc.LineTo(687,404);dc.LineTo(687,421);
	dc.MoveTo(292,253);	dc.LineTo(684,278);	dc.LineTo(683,296);
	dc.LineTo(701,402);	dc.LineTo(703,420);
	dc.SelectObject(oldPen);
	
	CPen penL2;
	penL2.CreatePen(PS_SOLID,2,RGB(37,34,29));
	oldPen =dc.SelectObject(&penL2);
	
	dc.MoveTo(629,258);dc.LineTo(438,239);
	dc.MoveTo(546,209);dc.LineTo(430,193);
	dc.MoveTo(441,106);dc.LineTo(274,75);dc.LineTo(198,171);
	dc.MoveTo(243,239);dc.LineTo(98,227);dc.LineTo(76,277);
	
	dc.SelectObject(oldPen);
	
	CPen penL3;
	penL3.CreatePen(PS_SOLID,2,RGB(34,26,23));
	oldPen =dc.SelectObject(&penL3);
	dc.MoveTo(247,145);dc.LineTo(247,284);
	dc.MoveTo(253,140);dc.LineTo(253,282);
	dc.MoveTo(260,131);dc.LineTo(259,278);
	dc.MoveTo(266,127);dc.LineTo(266,276);
	dc.MoveTo(273,272);dc.LineTo(273,116);
	
	dc.MoveTo(678,361);dc.LineTo(678,421);
	dc.MoveTo(663,420);dc.LineTo(663,299);
	dc.MoveTo(649,298);dc.LineTo(649,306);
	dc.MoveTo(649,383);dc.LineTo(649,411);
	dc.MoveTo(634,402);dc.LineTo(634,303);
	dc.MoveTo(650,385);dc.LineTo(650,383);
	dc.MoveTo(622,303);dc.LineTo(622,402);
	dc.MoveTo(633,309);dc.LineTo(650,305);
	dc.MoveTo(650,305);dc.LineTo(650,382);
	dc.MoveTo(650,382);dc.LineTo(633,383);
	dc.SelectObject(oldPen);

	CPen penL4;
	penL4.CreatePen(PS_SOLID,2,RGB(68,59,54));
	oldPen =dc.SelectObject(&penL4);
	dc.MoveTo(292,112);dc.LineTo(292,273);
	dc.MoveTo(314,118);dc.LineTo(314,138);
	dc.MoveTo(337,123);dc.LineTo(337,142);
	dc.MoveTo(359,127);dc.LineTo(359,146);
	dc.MoveTo(380,149);dc.LineTo(380,131);
	dc.MoveTo(402,153);dc.LineTo(402,135);
	dc.MoveTo(421,139);dc.LineTo(421,158);
	dc.MoveTo(442,143);dc.LineTo(442,162);
	dc.MoveTo(459,146);dc.LineTo(459,164);
	dc.MoveTo(316,256);dc.LineTo(316,274);
	dc.MoveTo(341,277);dc.LineTo(341,257);
	dc.MoveTo(389,280);dc.LineTo(389,259);
	dc.MoveTo(365,278);dc.LineTo(365,258);
	dc.MoveTo(411,280);dc.LineTo(411,260);
	dc.MoveTo(433,263);dc.LineTo(433,282);
	dc.MoveTo(477,265);dc.LineTo(477,283);
	dc.MoveTo(456,282);dc.LineTo(456,263);
	dc.MoveTo(498,286);dc.LineTo(498,265);
	dc.MoveTo(519,269);dc.LineTo(519,286);
	dc.MoveTo(559,270);dc.LineTo(559,288);
	dc.MoveTo(539,288);dc.LineTo(539,269);
	dc.MoveTo(578,291);dc.LineTo(578,271);
	dc.MoveTo(597,272);dc.LineTo(597,291);
	dc.MoveTo(633,275);dc.LineTo(633,292);
	dc.MoveTo(616,291);dc.LineTo(616,273);
	dc.MoveTo(651,294);dc.LineTo(651,275);
	dc.MoveTo(670,278);dc.LineTo(670,295);
	dc.SelectObject(oldPen);
	

	//2�� â�� Ʋ

	CPen penL5;
	penL5.CreatePen(PS_SOLID,3,RGB(144,127,99));
	oldPen =dc.SelectObject(&penL5);
	dc.MoveTo(310,252);dc.LineTo(310,158);dc.LineTo(409,172);dc.LineTo(409,257);
	dc.SelectObject(oldPen);

	//1�� âƲ
	CPen penL6;
	penL6.CreatePen(PS_SOLID,2,RGB(153,154,156));
	oldPen =dc.SelectObject(&penL6);
	dc.MoveTo(296,405);dc.LineTo(296,307);dc.LineTo(326,309);dc.LineTo(326,404);
	dc.MoveTo(346,404);dc.LineTo(346,310);dc.LineTo(376,312);dc.LineTo(376,404);
	dc.MoveTo(395,404);dc.LineTo(395,313);dc.LineTo(421,315);dc.LineTo(421,404);
	dc.MoveTo(442,404);dc.LineTo(442,315);dc.LineTo(539,320);dc.LineTo(539,404);
	dc.MoveTo(120,394);dc.LineTo(120,315);dc.LineTo(224,318);dc.LineTo(224,394);dc.LineTo(120,394);
	//2�� âƲ
		
	dc.MoveTo(481,242);dc.LineTo(481,235);dc.LineTo(522,239);dc.LineTo(522,246);
	dc.MoveTo(495,237);dc.LineTo(495,243);dc.MoveTo(508,245);dc.LineTo(508,238);
	dc.SelectObject(oldPen);
	
	CPen penL8;
	penL8.CreatePen(PS_SOLID,2,RGB(165,148,128));
	oldPen =dc.SelectObject(&penL8);
	dc.MoveTo(92,248);dc.LineTo(92,429);
	dc.MoveTo(88,428);dc.LineTo(88,256);
	dc.MoveTo(84,262);dc.LineTo(84,428);
	dc.SelectObject(oldPen);

	CPen penL7;
	penL7.CreatePen(PS_SOLID,4,RGB(67,71,74));
	oldPen =dc.SelectObject(&penL7);
	dc.MoveTo(83,282);dc.LineTo(83,310);
	dc.MoveTo(83,324);dc.LineTo(83,352);
	dc.MoveTo(83,365);dc.LineTo(83,393);
	dc.SelectObject(oldPen);


	
	//2�� ���� ���
	CPen pen30(PS_SOLID,2,RGB(73,57,41));
	CPen *pPen=pDC->SelectObject(&pen30);
	CBrush brush30(RGB(73,57,41));
	CBrush *pBrush=pDC->SelectObject(&brush30);

	int p_int60[][2] = {{455,166},{458,167},{458,263},{455,262}};
	CPoint p60[4];
	for(int i=0;i<sizeof(p_int60)/sizeof(int[2]);i++){
		p60[i].x=p_int60[i][0];
		p60[i].y=p_int60[i][1];
	}
	pDC->Polygon(p60,4);

	int p_int61[][2] = {{452,165},{452,262},{450,262},{450,165}};
	CPoint p61[4];
	for(int i=0;i<sizeof(p_int60)/sizeof(int[2]);i++){
		p61[i].x=p_int61[i][0];
		p61[i].y=p_int61[i][1];
	}
	pDC->Polygon(p61,4);

	int p_int62[][2] = {{446,163},{446,262},{444,262},{444,165}};
	CPoint p62[4];
	for(int i=0;i<sizeof(p_int62)/sizeof(int[2]);i++){
		p62[i].x=p_int62[i][0];
		p62[i].y=p_int62[i][1];
	}
	pDC->Polygon(p62,4);

	int p_int63[][2] = {{440,163},{440,262},{438,262},{438,163}};
	CPoint p63[4];
	for(int i=0;i<sizeof(p_int63)/sizeof(int[2]);i++){
		p63[i].x=p_int63[i][0];
		p63[i].y=p_int63[i][1];
	}
	pDC->Polygon(p63,4);

	int p_int64[][2] = {{434,163},{434,262},{432,261},{432,163}};
	CPoint p64[4];
	for(int i=0;i<sizeof(p_int64)/sizeof(int[2]);i++){
		p64[i].x=p_int64[i][0];
		p64[i].y=p_int64[i][1];
	}
	pDC->Polygon(p64,4);

	int p_int65[][2] = {{428,163},{428,261},{426,260},{426,161}};
	CPoint p65[4];
	for(int i=0;i<sizeof(p_int65)/sizeof(int[2]);i++){
		p65[i].x=p_int65[i][0];
		p65[i].y=p_int65[i][1];
	}
	pDC->Polygon(p65,4);

	int p_int66[][2] = {{422,161},{422,261},{420,260},{420,159},};
	CPoint p66[4];
	for(int i=0;i<sizeof(p_int66)/sizeof(int[2]);i++){
		p66[i].x=p_int66[i][0];
		p66[i].y=p_int66[i][1];
	}

	pDC->Polygon(p66,4);

	int p_int67[][2] = {{416,159},{416,260},{414,260},{414,159}};
	CPoint p67[4];
	for(int i=0;i<sizeof(p_int67)/sizeof(int[2]);i++){
		p67[i].x=p_int67[i][0];
		p67[i].y=p_int67[i][1];
	}

	pDC->Polygon(p67,4);

	int p_int68[][2] = {{410,159},{410,260},{408,260},{408,159}};
	CPoint p68[4];
	for(int i=0;i<sizeof(p_int68)/sizeof(int[2]);i++){
		p68[i].x=p_int68[i][0];
		p68[i].y=p_int68[i][1];
	}

	pDC->Polygon(p68,4);

	pDC->SelectObject(pPen);
	pDC->SelectObject(pBrush);
}


void CParkYooJinR1View::OnRButtonDown(UINT nFlags, CPoint point)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	
	CClientDC dc(this);
	DrawPattern2(&dc,point);	//�Է��Ѻκ�
	//Invalidate(false);

	CView::OnRButtonDown(nFlags, point);
	
}


void CParkYooJinR1View::DrawPattern(CDC* pDC, CPoint point)
{
	CClientDC dc(this); 
		CPen pen1, *pOldPen1;			
		CBrush brush1, *pOldBrush1;
		pen1.CreatePen(PS_SOLID,3,RGB(28,147,64));
		pOldPen1 = (CPen*)dc.SelectObject(&pen1);
		brush1.CreateSolidBrush(RGB(35,186,81));
		pOldBrush1 = (CBrush*)dc.SelectObject(&brush1);	
		dc.SelectObject(brush1);
		POINT pts1[]={
			{point.x-15, point.y+5}, {point.x-20, point.y-7},{point.x-10, point.y-2}, {point.x-2, point.y-10},
			{point.x+5, point.y-3},{point.x+15, point.y-8}, 
			{point.x+12, point.y+5}, {point.x-15,point.y+7}   
		};
		dc.Polygon(pts1, 8);
		dc.SelectObject(pOldPen1);
		dc.SelectObject(pOldBrush1);
}


void CParkYooJinR1View::DrawPattern2(CDC* pDC, CPoint point)
{
	CClientDC dc(this); 
		CPen pen2, *pOldPen2;			
		CBrush brush2, *pOldBrush2;
		pen2.CreatePen(PS_SOLID,3,RGB(192,85,235));
		pOldPen2 = (CPen*)dc.SelectObject(&pen2);
		brush2.CreateSolidBrush(RGB(255,0,255));
		pOldBrush2 = (CBrush*)dc.SelectObject(&brush2);	
		dc.SelectObject(brush2);
		POINT pts2[]={
			{point.x-6, point.y-9},{point.x-4, point.y-15},{point.x-2, point.y-18},{point.x+2, point.y-18},{point.x+4, point.y-15},{point.x+6, point.y-9},{point.x, point.y},
			{point.x+9, point.y-6},{point.x+14, point.y-6},{point.x+18, point.y-3},{point.x+18, point.y+3},{point.x+14, point.y+6},{point.x+9, point.y+6},{point.x, point.y},
			{point.x+6, point.y+9},{point.x+6, point.y+15},{point.x+4, point.y+18},{point.x-4, point.y+18},{point.x-6, point.y+15},{point.x-6, point.y+9},{point.x, point.y}, 
			{point.x-9, point.y+6},{point.x-15,point.y+6},{point.x-18,point.y+4},{point.x-18,point.y-4},{point.x-15,point.y-6},{point.x-9,point.y-6},{point.x, point.y}  
		};
		dc.Polygon(pts2, 28);
		dc.SelectObject(pOldPen2);
		dc.SelectObject(pOldBrush2);
		
}


void CParkYooJinR1View::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	
	CClientDC dc(this);
	if(sky==1)
		star=1;
	else
		star=0;
	Invalidate();

	//CView::OnKeyDown(nChar, nRepCnt, nFlags);
}


void CParkYooJinR1View::OnLightoff()
{
	// TODO: ���⿡ ���� ó���� �ڵ带 �߰��մϴ�.
	
		light=0;
		Invalidate(); 
}
void CParkYooJinR1View::OnLighton()
{
	// TODO: ���⿡ ���� ó���� �ڵ带 �߰��մϴ�.
	light=1;
	Invalidate();
}
void CParkYooJinR1View::OnOriginallight()
{
	// TODO: ���⿡ ���� ó���� �ڵ带 �߰��մϴ�.
	light =2;
	Invalidate();
	
}


void CParkYooJinR1View::OnDaysky()
{
	sky=2;
	star = 0;
	Invalidate();
	// TODO: ���⿡ ���� ó���� �ڵ带 �߰��մϴ�.
}


void CParkYooJinR1View::OnNightsky()
{
	sky=1;
	Invalidate();
	// TODO: ���⿡ ���� ó���� �ڵ带 �߰��մϴ�.
}


void CParkYooJinR1View::OnUpdateDaysky(CCmdUI *pCmdUI)
{
	// TODO: ���⿡ ���� ������Ʈ UI ó���� �ڵ带 �߰��մϴ�.
}


void CParkYooJinR1View::OnSnow()
{
	// TODO: ���⿡ ���� ó���� �ڵ带 �߰��մϴ�.
	weathers =2;
	Invalidate();
	KillTimer(0);
	SetTimer(1,300,NULL);
}


void CParkYooJinR1View::OnRain()
{
	// TODO: ���⿡ ���� ó���� �ڵ带 �߰��մϴ�.
	weathers =1;
	Invalidate();
	KillTimer(0);
	SetTimer(1,300,NULL);
}


void CParkYooJinR1View::OnSunny()
{
	// TODO: ���⿡ ���� ó���� �ڵ带 �߰��մϴ�.
	weathers =0;
	Invalidate();
	KillTimer(0);
}


void CParkYooJinR1View::backGround(CDC* pDC)
{
	if(sky==1){
		CDC MemDC;
		 BITMAP bmpInfo;

	   MemDC.CreateCompatibleDC(pDC);

	   CBitmap bmp;
		 CBitmap* pOldBmp = NULL;

	   bmp.LoadBitmap(IDB_BITMAP3);
		 bmp.GetBitmap(&bmpInfo);

		MemDC.SelectObject(&bmp);
	   pDC->BitBlt( 0, 0, bmpInfo.bmWidth, bmpInfo.bmHeight, &MemDC, 0, 0, SRCCOPY ); 
		
	}
	else{
		CDC MemDC;
		 BITMAP bmpInfo;

	   MemDC.CreateCompatibleDC(pDC);

	   CBitmap bmp;
		 CBitmap* pOldBmp = NULL;

	   bmp.LoadBitmap(IDB_BITMAP2);
		 bmp.GetBitmap(&bmpInfo);

		MemDC.SelectObject(&bmp);
	   pDC->BitBlt( 0, 0, bmpInfo.bmWidth, bmpInfo.bmHeight, &MemDC, 0, 0, SRCCOPY ); 

	}

	//��
	/*if(weathers==1){
		��¶�
		CPen bgpen2(PS_SOLID,2,RGB(52,184,98));
		CPen *pPen=pDC->SelectObject(&bgpen2);
		CBrush bgbrush2(RGB(52,184,98));
		CBrush *pBrush=pDC->SelectObject(&bgbrush2);
	
		int pbg_int2[][2] = {{0,401},{892,396},{892,467},{0,467}};
		CPoint p_bg2[4];
		for(int i=0;i<sizeof(pbg_int2)/sizeof(int[2]);i++){
			p_bg2[i].x=pbg_int2[i][0];
			p_bg2[i].y=pbg_int2[i][1];
		}
		pDC->Polygon(p_bg2,4);
	
		pDC->SelectObject(pPen);
		pDC->SelectObject(pBrush);
		}
	else if(weathers==2){
		//���ö� �ٴ� ���
	CPen bgpen2(PS_SOLID,2,RGB(255,255,255));
	CPen *pPen=pDC->SelectObject(&bgpen2);
	CBrush bgbrush2(RGB(255,255,255));
	CBrush *pBrush=pDC->SelectObject(&bgbrush2);
	
	int pbg_int2[][2] = {{0,401},{892,396},{892,467},{0,467}};
	CPoint p_bg2[4];
	for(int i=0;i<sizeof(pbg_int2)/sizeof(int[2]);i++){
		p_bg2[i].x=pbg_int2[i][0];
		p_bg2[i].y=pbg_int2[i][1];
	}
	pDC->Polygon(p_bg2,4);
	
	pDC->SelectObject(pPen);
	pDC->SelectObject(pBrush);
	}
	else{
		CPen bgpen3(PS_SOLID,2,RGB(138,247,99));
		CPen *pPen=pDC->SelectObject(&bgpen3);
		CBrush bgbrush3(RGB(138,247,99));
		CBrush *pBrush=pDC->SelectObject(&bgbrush3);
	
		int pbg_int3[][2] = {{0,401},{892,396},{892,467},{0,467}};
		CPoint p_bg3[4];
		for(int i=0;i<sizeof(pbg_int3)/sizeof(int[2]);i++){
			p_bg3[i].x=pbg_int3[i][0];
			p_bg3[i].y=pbg_int3[i][1];
		}
		pDC->Polygon(p_bg3,4);
	
		pDC->SelectObject(pPen);
		pDC->SelectObject(pBrush);
	}*/
}


//UINT CParkYooJinR1View::OnMenuGetObject(MENUGETOBJECTINFO* pMenuGetObjectInfo)
//{
//	// �� ����� ����Ϸ��� Windows 2000 �̻��� �ʿ��մϴ�.
//	// _WIN32_WINNT �� WINVER ��ȣ�� 0x0500���� ũ�ų� ���ƾ� �մϴ�.
//	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
//
//	return CView::OnMenuGetObject(pMenuGetObjectInfo);
//}


void CParkYooJinR1View::OnGetMinMaxInfo(MINMAXINFO* lpMMI)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	lpMMI->ptMinTrackSize = CPoint(400,400);
	lpMMI->ptMaxTrackSize = CPoint(400,400);
	CView::OnGetMinMaxInfo(lpMMI);
}

void CParkYooJinR1View::OnInitialUpdate()
{
	CView::OnInitialUpdate();

	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.

	SetTimer(0,1000,NULL); // 1�ʸ���
}


void CParkYooJinR1View::OnDestroy()
{
	CView::OnDestroy();

	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.

	KillTimer(0);
}


void CParkYooJinR1View::OnTimer(UINT_PTR nIDEvent)
{
		
	if(weathers == 2){ //��
		CClientDC dc(this);  // ȭ�� ����� ���� DC Ŭ����
		CRect rect;	// ȭ�� ũ�⸦ ��� ���� ����
		CBrush brush, *pOldBrush;	// �귯�� ������Ʈ
		CPen pen, *pOldPen;      	// �� ������Ʈ
		int  x1,y1;  	// ȭ�� ��ǥ
		int  nObject;               	// �׷��� Ÿ��
		GetClientRect(rect); 
		
		brush.CreateSolidBrush(RGB(255,255,255));  	// �귯�� ����
		pOldBrush = (CBrush *)dc.SelectObject(&brush); 
						// DC�� �귯�� ����
		pen.CreatePen(PS_SOLID, 15, RGB(255,255,255));   // �� ����
		pOldPen = (CPen *)dc.SelectObject(&pen);
		x1 = rand() % rect.right;	// ��ǥ�� �����ϰ� ����
		y1 = rand() % rect.bottom;

		dc.MoveTo(x1,y1);
		dc.LineTo(x1,y1);


		dc.SelectObject(pOldPen);	// DC ����
		dc.SelectObject(pOldBrush);
	}
	else if(weathers == 1){ // ��

		CClientDC dc(this);  // ȭ�� ����� ���� DC Ŭ����
		CRect rect;	// ȭ�� ũ�⸦ ��� ���� ����
		CBrush brush, *pOldBrush;	// �귯�� ������Ʈ
		CPen pen, *pOldPen;      	// �� ������Ʈ
		int  x1,y1,x2,y2;  	// ȭ�� ��ǥ
		int  nObject;               	// �׷��� Ÿ��
		GetClientRect(rect); 
		
		brush.CreateSolidBrush(RGB(63,105,218));  	// �귯�� ����
		pOldBrush = (CBrush *)dc.SelectObject(&brush); 
						// DC�� �귯�� ����
		pen.CreatePen(PS_SOLID, 5, RGB(63,105,218));   // �� ����
		pOldPen = (CPen *)dc.SelectObject(&pen);
		x1 = rand() % rect.right;	// ��ǥ�� �����ϰ� ����
		y1 = rand() % rect.bottom;
		x2 = x1-5;
		y2 = y1+15;

		dc.MoveTo(x1,y1);
		dc.LineTo(x2,y2);


		dc.SelectObject(pOldPen);	// DC ����
		dc.SelectObject(pOldBrush);
	}
	//else
	CView::OnTimer(nIDEvent);


}

void CParkYooJinR1View::OnLButtonDown(UINT nFlags, CPoint point)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
		CClientDC dc(this);
	
	//CString str;
	//str.Format(_T("{%d,%d},"),point.x,point.y);
	//OnDraw(&dc);
	//dc.TextOut(point.x,point.y,str);
	//vt.push_back(str);
	//------------------------------
	//if(pDoc->m_nCount<100){
	//	pDoc->m_ptData[pDoc->m_nCount]=point;
	//	pDoc->m_nCount++;
	//}
	DrawPattern(&dc,point);	//�Է��Ѻκ�
	Invalidate(false);

	CView::OnLButtonDown(nFlags, point);
}


BOOL CParkYooJinR1View::OnEraseBkgnd(CDC* pDC)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	CBrush backBrush(RGB(121,255,121));
	CBrush* pOldBrush = pDC->SelectObject(&backBrush);
	CRect rect; pDC->GetClipBox(&rect);
	pDC->PatBlt(rect.left, rect.top, rect.Width(), rect.Height(), PATCOPY);
	pDC->SelectObject(pOldBrush);
	return TRUE;

	return CView::OnEraseBkgnd(pDC);

	return CView::OnEraseBkgnd(pDC);
}
