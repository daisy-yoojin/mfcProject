#pragma once


// CBoardInfo1Dlg ��ȭ �����Դϴ�.

class CBoardInfo1Dlg : public CDialog
{
	DECLARE_DYNAMIC(CBoardInfo1Dlg)

public:
	CBoardInfo1Dlg(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CBoardInfo1Dlg();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_BoardInfo1 };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	
	CString m_strBName;
	CString m_phNum2;
	CString m_strAddress;
	CString m_PassNum;
	int m_Sexual;
	int m_Married;
	CString m_phNum3;
	CString m_BirNum;
//	CString m_phNum1;
	afx_msg void OnBnClickedOk2();
	CComboBox m_phNum1;
	afx_msg void OnBnClickedOk();
	virtual BOOL OnInitDialog();
	HBITMAP m_hBitmap; 
	BITMAP m_bBit;  
	afx_msg void OnPaint();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
};
