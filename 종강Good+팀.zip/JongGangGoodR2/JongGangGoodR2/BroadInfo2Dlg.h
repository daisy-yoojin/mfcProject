#pragma once


// CBroadInfo2Dlg ��ȭ �����Դϴ�.

class CBroadInfo2Dlg : public CDialog
{
	DECLARE_DYNAMIC(CBroadInfo2Dlg)

public:
	CBroadInfo2Dlg(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CBroadInfo2Dlg();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_BoardInfo2 };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	CString m_phNum1;
	CString m_phNum2;
	CString m_phNum3;
	CString m_strBName;
	CString m_BirNum;
	CString m_strAddress;
	CString m_PassNum;
	CString m_Sexual;
	CString m_Married;
	CComboBox m_Bwhere1;
	CComboBox m_Bwhere2;
	COleDateTime m_Bwhen1;
	COleDateTime m_Bwhen2;
//	CString m_BAdult;
//	CString m_BStudent;
//	CString m_BBaby;
	int m_BAdult;
	int m_BStudent;
	int m_BBaby;
	int m_BGo;
	int m_BCompany;
	int m_BSeat;
	CSpinButtonCtrl m_spAdult;
	CSpinButtonCtrl m_spStudent;
	CSpinButtonCtrl m_spBaby;
	afx_msg void OnDeltaposSpin2(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnDeltaposSpin3(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnDeltaposSpin4(NMHDR *pNMHDR, LRESULT *pResult);
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedOk2();
	afx_msg void OnBnClickedOk();
	HBITMAP m_hBitmap; 
	BITMAP m_bBit;  
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnPaint();
};
