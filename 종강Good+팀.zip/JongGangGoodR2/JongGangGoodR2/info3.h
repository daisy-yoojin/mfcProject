#pragma once


// info3 ��ȭ �����Դϴ�.

class info3 : public CDialog
{
	DECLARE_DYNAMIC(info3)

public:
	info3(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~info3();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_Credit };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedOk();
	int m_method;
	CString m_CName;
	CString m_CNum1;
	CString m_CNum2;
	CString m_CPwd;
	CString m_CDate;
	CString m_CNum3;
	CString m_CNum4;
	CComboBox m_CAccount;
	CComboBox m_CCompany;
	afx_msg void OnBnClickedRadio3();
	afx_msg void OnBnClickedRadio4();
	virtual BOOL OnInitDialog();
	HBITMAP m_hBitmap; 
	BITMAP m_bBit;  
	afx_msg void OnPaint();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
};
