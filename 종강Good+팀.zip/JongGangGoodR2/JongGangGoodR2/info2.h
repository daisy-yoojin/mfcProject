#pragma once


// info2 ��ȭ �����Դϴ�.

class info2 : public CDialog
{
	DECLARE_DYNAMIC(info2)

public:
	info2(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~info2();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_INFO2 };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	CComboBox m_where1;
	CComboBox m_where2;
	virtual BOOL OnInitDialog();
	CString m_date1;
	CString m_date2;
//	CComboBox m_adult;
//	CComboBox m_child;
//	CComboBox m_baby;
	
	CString m_name;
	CString m_age;
	CString phone1;
	CString m_phone2;
	CString m_phone3;
	CString m_address;
	CString sex;
	CString marriage;

	int m_go;
	int m_transfer;
	int m_air;
	int m_ship;
	int m_adult;
	int m_child;
	int m_baby;
	afx_msg void OnDeltaposSpin1(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnDeltaposSpin2(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnDeltaposSpin3(NMHDR *pNMHDR, LRESULT *pResult);
//	CDateTimeCtrl m_closeGo;
	CDateTimeCtrl m_closeBack;
	afx_msg void OnBnClickedRadio2();
	afx_msg void OnBnClickedRadio1();
	CButton m_closeAir;
//	CButton m_clsoeShip;
	afx_msg void OnBnClickedRadio3();
	CButton m_closeShip;
	afx_msg void OnBnClickedRadio5();
	afx_msg void OnBnClickedOk2();
	afx_msg void OnBnClickedOk();
	COleDateTime m_time1;
	COleDateTime m_time2;
	afx_msg void OnBnClickedRadio12();
	CComboBox m_RoomLevel;
	CComboBox m_RoomType;
	CComboBox m_CRoomType;
	CComboBox m_CSleep;
	int m_Inn;
	int m_GRoomType;
	afx_msg void OnBnClickedRadio13();
	afx_msg void OnBnClickedRadio14();
	HBITMAP m_hBitmap; 
	BITMAP m_bBit;  
	afx_msg void OnPaint();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
};
