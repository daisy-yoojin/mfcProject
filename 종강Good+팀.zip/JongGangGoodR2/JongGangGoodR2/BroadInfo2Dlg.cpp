// BroadInfo2Dlg.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "JongGangGoodR2.h"
#include "BroadInfo2Dlg.h"
#include "afxdialogex.h"


// CBroadInfo2Dlg ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CBroadInfo2Dlg, CDialog)

CBroadInfo2Dlg::CBroadInfo2Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CBroadInfo2Dlg::IDD, pParent)
{

	m_Bwhen1 = COleDateTime::GetCurrentTime();
	m_Bwhen2 = COleDateTime::GetCurrentTime();
	//  m_BAdult = _T("");
	//  m_BStudent = _T("");
	//  m_BBaby = _T("");
	m_BAdult = 0;
	m_BStudent = 0;
	m_BBaby = 0;
	m_BGo = 0;
	m_BCompany = 0;
	m_BSeat = 0;
}

CBroadInfo2Dlg::~CBroadInfo2Dlg()
{
}

void CBroadInfo2Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_COMBO3, m_Bwhere1);
	DDX_Control(pDX, IDC_COMBO1, m_Bwhere2);
	DDX_DateTimeCtrl(pDX, IDC_DATETIMEPICKER2, m_Bwhen1);
	DDX_DateTimeCtrl(pDX, IDC_DATETIMEPICKER3, m_Bwhen2);
	//  DDX_Text(pDX, IDC_EDIT1, m_BAdult);
	//  DDX_Text(pDX, IDC_EDIT3, m_BStudent);
	//  DDX_Text(pDX, IDC_EDIT4, m_BBaby);
	DDX_Text(pDX, IDC_EDIT1, m_BAdult);
	DDX_Text(pDX, IDC_EDIT3, m_BStudent);
	DDX_Text(pDX, IDC_EDIT4, m_BBaby);
	DDX_Radio(pDX, IDC_RADIO1, m_BGo);
	DDX_Radio(pDX, IDC_RADIO3, m_BCompany);
	DDX_Radio(pDX, IDC_RADIO6, m_BSeat);
	DDX_Control(pDX, IDC_SPIN2, m_spAdult);
	DDX_Control(pDX, IDC_SPIN3, m_spStudent);
	DDX_Control(pDX, IDC_SPIN4, m_spBaby);
}


BEGIN_MESSAGE_MAP(CBroadInfo2Dlg, CDialog)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN2, &CBroadInfo2Dlg::OnDeltaposSpin2)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN3, &CBroadInfo2Dlg::OnDeltaposSpin3)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN4, &CBroadInfo2Dlg::OnDeltaposSpin4)
	ON_BN_CLICKED(IDOK2, &CBroadInfo2Dlg::OnBnClickedOk2)
	ON_BN_CLICKED(IDOK, &CBroadInfo2Dlg::OnBnClickedOk)
	ON_WM_CTLCOLOR()
	ON_WM_PAINT()
END_MESSAGE_MAP()


// CBroadInfo2Dlg �޽��� ó�����Դϴ�.


void CBroadInfo2Dlg::OnDeltaposSpin2(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	if(pNMUpDown->iDelta<0){
		if(m_BAdult<100){m_BAdult++;}
	}else{
		if(m_BAdult>0){m_BAdult--;}
	}
	SetDlgItemInt(IDC_EDIT1,m_BAdult);
	*pResult = 0;
}


void CBroadInfo2Dlg::OnDeltaposSpin3(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.

	if(pNMUpDown->iDelta<0){
		if(m_BStudent<100){m_BStudent++;}
	}else{
		if(m_BStudent>0){m_BStudent--;}
	}
	SetDlgItemInt(IDC_EDIT3,m_BStudent);

	*pResult = 0;
}


void CBroadInfo2Dlg::OnDeltaposSpin4(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.

	if(pNMUpDown->iDelta<0){
		if(m_BBaby<100){m_BBaby++;}
	}else{
		if(m_BBaby>0){m_BBaby--;}
	}
	SetDlgItemInt(IDC_EDIT4,m_BBaby);

	*pResult = 0;
}


BOOL CBroadInfo2Dlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	m_Bwhere1.AddString(_T("��õ"));
	m_Bwhere1.AddString(_T("����"));
	m_Bwhere1.AddString(_T("�θ�"));
	m_Bwhere1.AddString(_T("�Ͻ�"));
	m_Bwhere1.AddString(_T("����ī"));
	m_Bwhere1.AddString(_T("ȫ��"));
	m_Bwhere1.AddString(_T("���Ҷ�"));
	m_Bwhere1.AddString(_T("�õ��"));
	m_Bwhere1.AddString(_T("����"));
	m_Bwhere1.AddString(_T("������"));
	m_Bwhere1.AddString(_T("�����"));
	m_Bwhere1.AddString(_T("īƮ����"));
	m_Bwhere1.AddString(_T("�߽��ڽ�Ƽ"));
	m_Bwhere1.AddString(_T("�ι���"));
	m_Bwhere1.AddString(_T("��"));
	m_Bwhere1.AddString(_T("��Ŭ����"));
	m_Bwhere1.AddString(_T("�븮��"));
	
	m_Bwhere1.SetCurSel(13);


	m_Bwhere2.AddString(_T("��õ"));
	m_Bwhere2.AddString(_T("����"));
	m_Bwhere2.AddString(_T("�θ�"));
	m_Bwhere2.AddString(_T("�Ͻ�"));
	m_Bwhere2.AddString(_T("����ī"));
	m_Bwhere2.AddString(_T("ȫ��"));
	m_Bwhere2.AddString(_T("���Ҷ�"));
	m_Bwhere2.AddString(_T("�õ��"));
	m_Bwhere2.AddString(_T("����"));
	m_Bwhere2.AddString(_T("������"));
	m_Bwhere2.AddString(_T("�����"));
	m_Bwhere2.AddString(_T("īƮ����"));
	m_Bwhere2.AddString(_T("�߽��ڽ�Ƽ"));
	m_Bwhere2.AddString(_T("�ι���"));
	m_Bwhere2.AddString(_T("��"));
	m_Bwhere2.AddString(_T("��Ŭ����"));
	m_Bwhere2.AddString(_T("�븮��"));

	m_Bwhere2.SetCurSel(4);

	CRect rect;
    GetClientRect(&rect);

    m_hBitmap = LoadBitmap(AfxGetApp()->m_hInstance, MAKEINTRESOURCE(IDB_ExternalBG));
    GetObject(m_hBitmap, sizeof(BITMAP), &m_bBit);

	SetWindowTheme(GetDlgItem(IDC_GOBACK)->m_hWnd, _T(""), _T(""));
	SetWindowTheme(GetDlgItem(IDC_WHEN)->m_hWnd, _T(""), _T(""));
	SetWindowTheme(GetDlgItem(IDC_PEOPLE)->m_hWnd, _T(""), _T(""));
	SetWindowTheme(GetDlgItem(IDC_AIR)->m_hWnd, _T(""), _T(""));
	SetWindowTheme(GetDlgItem(IDC_SEAT)->m_hWnd, _T(""), _T(""));
	SetWindowTheme(GetDlgItem(IDC_RADIO1)->m_hWnd, _T(""), _T(""));
	SetWindowTheme(GetDlgItem(IDC_RADIO2)->m_hWnd, _T(""), _T(""));
	SetWindowTheme(GetDlgItem(IDC_RADIO3)->m_hWnd, _T(""), _T(""));
	SetWindowTheme(GetDlgItem(IDC_RADIO4)->m_hWnd, _T(""), _T(""));
	SetWindowTheme(GetDlgItem(IDC_RADIO5)->m_hWnd, _T(""), _T(""));
	SetWindowTheme(GetDlgItem(IDC_RADIO6)->m_hWnd, _T(""), _T(""));
	SetWindowTheme(GetDlgItem(IDC_RADIO7)->m_hWnd, _T(""), _T(""));
	SetWindowTheme(GetDlgItem(IDC_RADIO8)->m_hWnd, _T(""), _T(""));
	

	// TODO:  ���⿡ �߰� �ʱ�ȭ �۾��� �߰��մϴ�.

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}

#include "BoardInfo1Dlg.h"
void CBroadInfo2Dlg::OnBnClickedOk2()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	ShowWindow(false);
	CBoardInfo1Dlg dlg1;
	dlg1.DoModal();
	EndDialog(0);
}

#include "BoardInfo3.h"
void CBroadInfo2Dlg::OnBnClickedOk()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	UpdateData(true);
	CString where1,where2,when1,when2,company,seat;
	when1 = m_Bwhen1.Format(_T("%Y, %B, %d"));
	when2 = m_Bwhen2.Format(_T("%Y, %B, %d"));
	m_Bwhere1.GetLBText(m_Bwhere1.GetCurSel(), where1);
	m_Bwhere2.GetLBText(m_Bwhere2.GetCurSel(), where2);
	
	if(m_BCompany == 0)
		company.Format(L"KOREAN AIR");
	else if(m_BCompany == 1)
		company.Format(L"ASIANA AIR");
	else
		company.Format(L"HANSHIN AIR");

	if(m_BSeat == 0)
		seat.Format(L"FIRST");
	else if(m_BSeat == 1)
		seat.Format(L"BUSINESS");
	else
		seat.Format(L"ECONOMY");

	ShowWindow(false);
	
	BoardInfo3 dlg3;
	dlg3.m_phNum1 = m_phNum1;
	dlg3.m_phNum2 = m_phNum2;
	dlg3.m_phNum3 = m_phNum3;
	dlg3.m_strBName = m_strBName;
	dlg3.m_BirNum = m_BirNum;
	dlg3.m_strAddress = m_strAddress;
	dlg3.m_PassNum = m_PassNum;
	dlg3.m_Sexual = m_Sexual;
	dlg3.m_Married = m_Married;

	dlg3.m_Bwhere2 = where2;
	dlg3.m_Bwhere1 = where1;
	dlg3.m_Bwhen2 = when2;
	dlg3.m_Bwhen1 = when1;
	dlg3.m_BAdult = m_BAdult;
	dlg3.m_BStudent = m_BStudent;
	dlg3.m_BBaby = m_BBaby;
	dlg3.m_BGo = m_BGo;
	dlg3.m_BCompany = company;
	dlg3.m_BSeat = seat;

	dlg3.DoModal();
	EndDialog(0);

	CDialog::OnOK();
}


HBRUSH CBroadInfo2Dlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);

	// TODO:  ���⼭ DC�� Ư���� �����մϴ�.
	if(nCtlColor == CTLCOLOR_STATIC)
	{
   //pDC->SetTextColor(RGB(255, 255, 255));  // static text ���ڻ� ����
   pDC->SetBkMode(TRANSPARENT);   // static text ���� ����
   return (HBRUSH)::GetStockObject(NULL_BRUSH);
	}

	// TODO:  �⺻���� �������� ������ �ٸ� �귯�ø� ��ȯ�մϴ�.
	return hbr;
}


void CBroadInfo2Dlg::OnPaint()
{
	CPaintDC dc(this); // device context for painting
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
	// �׸��� �޽����� ���ؼ��� CDialog::OnPaint()��(��) ȣ������ ���ʽÿ�.
	CRect rect;
   GetClientRect(&rect);
   HDC hdc = ::GetDC(this->m_hWnd);
   HDC hMemDC = CreateCompatibleDC(dc);
   SelectObject(hMemDC, m_hBitmap);
   //BitBlt(dc, 0, 0, rect.Width(), rect.Height(), hMemDC, 0, 0, SRCCOPY);
   SetStretchBltMode(hdc, COLORONCOLOR);
   StretchBlt(hdc, 0, 0, rect.Width(), rect.Height(), hMemDC, 0, 0, m_bBit.bmWidth, m_bBit.bmHeight, SRCCOPY);
   DeleteDC(hMemDC);
}
