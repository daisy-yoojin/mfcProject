#pragma once

// BoardInfo3 ��ȭ �����Դϴ�.

class BoardInfo3 : public CDialog
{
	DECLARE_DYNAMIC(BoardInfo3)

public:
	BoardInfo3(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~BoardInfo3();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_DIALOG1 };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedRadio1();
	afx_msg void OnBnClickedRadio2();
	CComboBox m_HLevel;
	CComboBox m_RLevel;
	CComboBox m_RTtype;
//	CButton m_Inn;
	CString m_phNum1;
	CString m_phNum2;
	CString m_phNum3;
	CString m_strBName;
	CString m_BirNum;
	CString m_strAddress;
	CString m_PassNum;
	CString m_Sexual;
	CString m_Married;
	//1���� �ѱ��
	CString m_Bwhere2;
	CString m_Bwhere1;
	CString m_Bwhen1;
	CString m_Bwhen2;
	int m_BAdult;
	int m_BStudent;
	int m_BBaby;
	int m_BGo;
	CString m_BCompany;
	CString m_BSeat;
	//2���� �ѱ��
	int m_Inn;
	CString roomSize;//��
	//	int m_RSize;
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedOk2();
	afx_msg void OnBnClickedOk();
	void RadioCtrl(UINT ID);
	int m_RSize;
//	int m_size;
	HBITMAP m_hBitmap; 
	BITMAP m_bBit;  
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnPaint();
};
