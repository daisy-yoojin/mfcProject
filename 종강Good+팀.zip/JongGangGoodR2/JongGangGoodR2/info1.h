#pragma once


// info1 ��ȭ �����Դϴ�.

class info1 : public CDialog
{
	DECLARE_DYNAMIC(info1)

public:
	info1(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~info1();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_INFO1 };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	CBitmap m_background;
	int m_gender;
	int m_married;
	CString m_name;
	CString m_age;
//	CEdit m_phone2;
	CString m_phone2;
	CString m_phone3;
	CString m_address;
	afx_msg void OnBnClickedRadio1();
	afx_msg void OnBnClickedRadio3();
	afx_msg void OnBnClickedOk();
	afx_msg void OnCbnSelchangeCombo1();
	virtual BOOL OnInitDialog();
	CComboBox m_phone1;
	afx_msg void OnBnClickedCancel();
	afx_msg void OnEnChangeEdit1();
	CString sex;
	CString marriage;
	CString phone1;
	CStatic m_imgBg4;
	HBITMAP m_hBitmap; 
	BITMAP m_bBit;  
	//afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnPaint();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
};
