// BoardInfo1Dlg.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "JongGangGoodR2.h"
#include "BoardInfo1Dlg.h"
#include "afxdialogex.h"


// CBoardInfo1Dlg ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CBoardInfo1Dlg, CDialog)

CBoardInfo1Dlg::CBoardInfo1Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CBoardInfo1Dlg::IDD, pParent)
{

	m_strBName = _T("");
	m_strBName = _T("");
	//  m_BirNum = 0;
	//  m_phNum1 = 0;
	m_phNum2 = _T("");
	//  m_phNum3 = 0;
	m_strAddress = _T("");
	m_PassNum = _T("");
	m_Sexual = 0;
	m_Married = 0;
	m_phNum3 = _T("");
	m_BirNum = _T("");
	//  m_phNum1 = _T("");
}

CBoardInfo1Dlg::~CBoardInfo1Dlg()
{
}

void CBoardInfo1Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_strBName);
	//  DDX_Text(pDX, IDC_EDIT2, m_BirNum);
	//  DDX_CBIndex(pDX, IDC_COMBO1, m_phNum1);
	DDX_Text(pDX, IDC_EDIT4, m_phNum2);
	//  DDX_Text(pDX, IDC_EDIT5, m_phNum3);
	DDX_Text(pDX, IDC_EDIT6, m_strAddress);
	DDX_Text(pDX, IDC_EDIT7, m_PassNum);
	DDX_Radio(pDX, IDC_RADIO1, m_Sexual);
	DDX_Radio(pDX, IDC_RADIO3, m_Married);
	DDX_Text(pDX, IDC_EDIT5, m_phNum3);
	DDX_Text(pDX, IDC_EDIT2, m_BirNum);
	//  DDX_CBString(pDX, IDC_COMBO1, m_phNum1);
	DDX_Control(pDX, IDC_COMBO1, m_phNum1);
}


BEGIN_MESSAGE_MAP(CBoardInfo1Dlg, CDialog)
//	ON_BN_CLICKED(IDOK2, &CBoardInfo1Dlg::OnBnClickedOk2)
	ON_BN_CLICKED(IDOK, &CBoardInfo1Dlg::OnBnClickedOk)
	ON_WM_PAINT()
	ON_WM_CTLCOLOR()
END_MESSAGE_MAP()


// CBoardInfo1Dlg �޽��� ó�����Դϴ�.


#include "BroadInfo2Dlg.h"

void CBoardInfo1Dlg::OnBnClickedOk()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	UpdateData(true);
	CString phone1,sexual,married;
	m_phNum1.GetLBText(m_phNum1.GetCurSel(),phone1);
	
	if(m_Sexual == 0)
		sexual.Format(L"����");
	else
		sexual.Format(L"����");
	if(m_Married == 0)
		married.Format(L"��ȥ");
	else
		married.Format(L"��ȥ");
	
	ShowWindow(false);
		
	CBroadInfo2Dlg Binfo2;
	Binfo2.m_phNum1 = phone1; 
	Binfo2.m_phNum2 = m_phNum2;
	Binfo2.m_phNum3 = m_phNum3;
	Binfo2.m_strBName = m_strBName;
	Binfo2.m_BirNum = m_BirNum;
	Binfo2.m_strAddress = m_strAddress;
	Binfo2.m_PassNum = m_PassNum;
	Binfo2.m_Sexual = sexual;
	Binfo2.m_Married = married;

	Binfo2.DoModal();
	EndDialog(0);
	CDialog::OnOK();
}


BOOL CBoardInfo1Dlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  ���⿡ �߰� �ʱ�ȭ �۾��� �߰��մϴ�.
	m_phNum1.AddString(_T("010"));
	m_phNum1.AddString(_T("011"));
	m_phNum1.AddString(_T("016"));
	m_phNum1.AddString(_T("017"));
	m_phNum1.SetCurSel(0);
	
	CRect rect;
    GetClientRect(&rect);

    m_hBitmap = LoadBitmap(AfxGetApp()->m_hInstance, MAKEINTRESOURCE(IDB_ExternalBG));
    GetObject(m_hBitmap, sizeof(BITMAP), &m_bBit);
	
	SetWindowTheme(GetDlgItem(IDC_PPLINFO)->m_hWnd, _T(""), _T(""));
	SetWindowTheme(GetDlgItem(IDC_SEX)->m_hWnd, _T(""), _T(""));
	SetWindowTheme(GetDlgItem(IDC_MARRIED)->m_hWnd, _T(""), _T(""));
	SetWindowTheme(GetDlgItem(IDC_RADIO1)->m_hWnd, _T(""), _T(""));
	SetWindowTheme(GetDlgItem(IDC_RADIO2)->m_hWnd, _T(""), _T(""));
	SetWindowTheme(GetDlgItem(IDC_RADIO3)->m_hWnd, _T(""), _T(""));
	SetWindowTheme(GetDlgItem(IDC_RADIO4)->m_hWnd, _T(""), _T(""));

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}


void CBoardInfo1Dlg::OnPaint()
{
	CPaintDC dc(this); // device context for painting
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
	CRect rect;
   GetClientRect(&rect);
   HDC hdc = ::GetDC(this->m_hWnd);
   HDC hMemDC = CreateCompatibleDC(dc);
   SelectObject(hMemDC, m_hBitmap);
   //BitBlt(dc, 0, 0, rect.Width(), rect.Height(), hMemDC, 0, 0, SRCCOPY);
   SetStretchBltMode(hdc, COLORONCOLOR);
   StretchBlt(hdc, 0, 0, rect.Width(), rect.Height(), hMemDC, 0, 0, m_bBit.bmWidth, m_bBit.bmHeight, SRCCOPY);
   DeleteDC(hMemDC);
	// �׸��� �޽����� ���ؼ��� CDialog::OnPaint()��(��) ȣ������ ���ʽÿ�.
}


HBRUSH CBoardInfo1Dlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);

	// TODO:  ���⼭ DC�� Ư���� �����մϴ�.
	if(nCtlColor == CTLCOLOR_STATIC)
	{
   //pDC->SetTextColor(RGB(255, 255, 255));  // static text ���ڻ� ����
   pDC->SetBkMode(TRANSPARENT);   // static text ���� ����
   return (HBRUSH)::GetStockObject(NULL_BRUSH);
	}
	// TODO:  �⺻���� �������� ������ �ٸ� �귯�ø� ��ȯ�մϴ�.
	return hbr;
}
